from django.apps import AppConfig


class VuetifyformsConfig(AppConfig):
    name = "vuetifyforms"
