"""App name"""

from django.apps import AppConfig


class X509PkiConfig(AppConfig):
    name = "x509_pki"
