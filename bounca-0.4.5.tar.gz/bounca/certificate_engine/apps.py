"""App name"""

from django.apps import AppConfig


class CertificateEngineConfig(AppConfig):
    name = "certificate_engine"
